package mundial;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Seleccion[] selecciones = new Seleccion[48];
        Partido[] partidos = new Partido[200];

        int totalSelecciones = 0;
        int totalPartidos = 0;

        int opcion = 0;

        while (opcion != 4) {

            System.out.println("\n===== MUNDIAL FIFA =====");
            System.out.println("1. Registrar Partido");
            System.out.println("2. Ver Tabla de Posiciones");
            System.out.println("3. Ver Resultados");
            System.out.println("4. Salir");

            System.out.print("Seleccione una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {

                case 1:

                    System.out.print("Ingrese seleccion local: ");
                    String nombreLocal = sc.nextLine();

                    System.out.print("Ingrese seleccion visitante: ");
                    String nombreVisitante = sc.nextLine();

                    Seleccion local = null;
                    Seleccion visitante = null;

                    for (int i = 0; i < totalSelecciones; i++) {

                        if (selecciones[i].getNombre()
                                .equalsIgnoreCase(nombreLocal)) {

                            local = selecciones[i];
                        }

                        if (selecciones[i].getNombre()
                                .equalsIgnoreCase(nombreVisitante)) {

                            visitante = selecciones[i];
                        }
                    }

                    if (local == null) {

                        if (totalSelecciones < 48) {

                            local = new Seleccion(nombreLocal);

                            selecciones[totalSelecciones] = local;

                            totalSelecciones++;
                        }
                    }

                    if (visitante == null) {

                        if (totalSelecciones < 48) {

                            visitante = new Seleccion(nombreVisitante);

                            selecciones[totalSelecciones] = visitante;

                            totalSelecciones++;
                        }
                    }

                    System.out.print(
                            "¿Cuantos goles realizó "
                            + local.getNombre()
                            + "? "
                    );

                    int golesLocal = sc.nextInt();

                    System.out.print(
                            "¿Cuantos goles realizó "
                            + visitante.getNombre()
                            + "? "
                    );

                    int golesVisitante = sc.nextInt();

                    Partido partido = new Partido(
                            local,
                            visitante,
                            golesLocal,
                            golesVisitante
                    );

                    partido.procesarResultado();

                    partidos[totalPartidos] = partido;

                    totalPartidos++;

                    break;

                case 2:

                    for (int i = 0; i < totalSelecciones - 1; i++) {

                        for (int j = 0;
                                j < totalSelecciones - 1 - i;
                                j++) {

                            boolean intercambiar = false;

                            if (selecciones[j].getPuntos() < selecciones[j + 1].getPuntos()) {

                                intercambiar = true;
                            } else if (selecciones[j].getPuntos()
                                    == selecciones[j + 1].getPuntos()) {

                                if (selecciones[j]
                                        .getDiferenciaGoles()
                                        < selecciones[j + 1]
                                                .getDiferenciaGoles()) {

                                    intercambiar = true;
                                }
                            }

                            if (intercambiar) {

                                Seleccion aux
                                        = selecciones[j];

                                selecciones[j]
                                        = selecciones[j + 1];

                                selecciones[j + 1] = aux;
                            }
                        }
                    }

                    System.out.println(
                            "\nSELECCION       PJ  PG  PE  PP  GF  GC  PTS"
                    );

                    for (int i = 0; i < totalSelecciones; i++) {

                        selecciones[i].mostrarTabla();
                    }

                    break;

                case 3:

                    System.out.println("\nRESULTADOS");

                    if (totalPartidos == 0) {

                        System.out.println(
                                "No existen partidos registrados."
                        );

                    } else {

                        for (int i = 0;
                                i < totalPartidos;
                                i++) {

                            partidos[i].mostrarResultado();
                        }
                    }

                    break;

                case 4:

                    System.out.println(
                            "Gracias por utilizar el sistema."
                    );

                    break;

                default:

                    System.out.println(
                            "Opción inválida."
                    );
            }
        }

        sc.close();
    }
}
