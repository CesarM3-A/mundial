package mundial;

public class Partido {

    private Seleccion local;
    private Seleccion visitante;

    private int golesLocal;
    private int golesVisitante;

    public Partido(Seleccion local,
                   Seleccion visitante,
                   int golesLocal,
                   int golesVisitante) {

        this.local = local;
        this.visitante = visitante;

        this.golesLocal = golesLocal;
        this.golesVisitante = golesVisitante;
    }

    public void procesarResultado() {

        if (golesLocal > golesVisitante) {

            local.registrarVictoria(
                    golesLocal,
                    golesVisitante
            );

            visitante.registrarDerrota(
                    golesVisitante,
                    golesLocal
            );

            System.out.println(
                    local.getNombre() + " ganó el partido."
            );

        } else if (golesLocal < golesVisitante) {

            visitante.registrarVictoria(
                    golesVisitante,
                    golesLocal
            );

            local.registrarDerrota(
                    golesLocal,
                    golesVisitante
            );

            System.out.println(
                    visitante.getNombre() + " ganó el partido."
            );

        } else {

            local.registrarEmpate(
                    golesLocal,
                    golesVisitante
            );

            visitante.registrarEmpate(
                    golesVisitante,
                    golesLocal
            );

            System.out.println("Empate.");
        }
    }

    public void mostrarResultado() {

        System.out.println(
                local.getNombre()
                        + " "
                        + golesLocal
                        + " - "
                        + golesVisitante
                        + " "
                        + visitante.getNombre()
        );
    }
}