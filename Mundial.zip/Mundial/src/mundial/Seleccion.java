package mundial;

public class Seleccion extends Equipo {

    private int partidosJugados;
    private int partidosGanados;
    private int partidosEmpatados;
    private int partidosPerdidos;

    private int golesFavor;
    private int golesContra;

    public Seleccion(String nombre) {

        super(nombre);

        partidosJugados = 0;
        partidosGanados = 0;
        partidosEmpatados = 0;
        partidosPerdidos = 0;

        golesFavor = 0;
        golesContra = 0;
    }

    public void registrarVictoria(int golesAFavor, int golesEnContra) {

        partidosJugados++;
        partidosGanados++;

        golesFavor = golesFavor + golesAFavor;
        golesContra = golesContra + golesEnContra;

        puntos = puntos + 3;
    }

    public void registrarEmpate(int golesAFavor, int golesEnContra) {

        partidosJugados++;
        partidosEmpatados++;

        golesFavor = golesFavor + golesAFavor;
        golesContra = golesContra + golesEnContra;

        puntos = puntos + 1;
    }

    public void registrarDerrota(int golesAFavor, int golesEnContra) {

        partidosJugados++;
        partidosPerdidos++;

        golesFavor = golesFavor + golesAFavor;
        golesContra = golesContra + golesEnContra;
    }

    public int getDiferenciaGoles() {
        return golesFavor - golesContra;
    }

    public void mostrarTabla() {

        System.out.printf(
                "%-15s %-3d %-3d %-3d %-3d %-3d %-3d %-3d%n",
                nombre,
                partidosJugados,
                partidosGanados,
                partidosEmpatados,
                partidosPerdidos,
                golesFavor,
                golesContra,
                puntos
        );
    }
}